import { Component } from '@angular/core';

@Component({
  selector: 'app-show-users',
  standalone: true,
  imports: [],
  templateUrl: './show-users.component.html',
  styleUrl: './show-users.component.css'
})
export class ShowUsersComponent {

}
